function [x] = genp(A,b)

    Aaug = [A,b];
    m = length(A);
    L = eye(m);
    
    for j=1:(m-1)
        for k=j+1:m
            L(k,j) = Aaug(k,j)/Aaug(j,j);
            Aaug(k,j:m+1) = Aaug(k,j:m+1) - L(k,j)*Aaug(j,j:m+1);
        end
    end
    
    x = backsubstitution(Aaug);

end

