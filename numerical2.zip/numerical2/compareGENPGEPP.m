function [] = compareGENPGEPP(n,N)

    e1 = zeros(1,N);
    e2 = zeros(1,N);

    for i=1:N
        A = randn(n);
        b = randn(n,1);
        
        x = A\b;
        x1 = genp(A,b);
        x2 = gepp(A,b);
        
        e1(1,i) = sqrt(sum((x1-x).*(x1-x)));
        e2(1,i) = sqrt(sum((x2-x).*(x2-x)));
        
    end
    
    figure(1);
    plot(1:N,e1,'r-o');
    hold on;
    plot(1:N,e2,'b-o');
    legend('GENP error','GEPP error');
    title('Error comparison between GENP and GEPP');
    
end

