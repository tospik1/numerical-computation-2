function [L,U] = myLU(A)

    L = eye(length(A));
    
    for j=1:(length(A)-1)
        
        for i=(j+1):length(A)
            L(i,j) = A(i,j)/A(j,j);
            A(i,:) = A(i,:) - L(i,j)*A(j,:);
        end
        
    end
    L
    U = A
    
end

