function [x] = gepp(A, b)

    Aaug = [A,b];
    m = length(A);
    L = eye(m);
    P = eye(m);
    
    for j=1:(m-1)
        [M,i] = max(Aaug(j:m,j));
        i = i+j-1;
        temp = Aaug(j,j:m+1);
        Aaug(j,j:m+1) = Aaug(i,j:m+1);
        Aaug(i,j:m+1) = temp;
        
        temp = L(j,1:j-1);
        L(j,1:j-1) = L(i,1:j-1);
        L(i,1:j-1) = temp;
        
        temp = P(j,:);
        P(j,:) = P(i,:);
        P(i,:) = temp;
        
        for k=j+1:m
            L(k,j) = Aaug(k,j)/Aaug(j,j);
            Aaug(k,j:m+1) = Aaug(k,j:m+1) - L(k,j)*Aaug(j,j:m+1);
        end
    end
    
    x = backsubstitution(Aaug);

end

