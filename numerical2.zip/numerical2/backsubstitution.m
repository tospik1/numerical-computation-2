function [x] = backsubstitution(Aaug)

    n = size(Aaug,1);
    U = Aaug(:,1:n);
    b = Aaug(:,n+1);
    
    x = zeros(n,1);
    
    for i=n:-1:1
        
        x(i) = b(i)/U(i,i);
        b(1:i-1) = b(1:i-1) - U(1:i-1,i)*x(i);
    end

end

